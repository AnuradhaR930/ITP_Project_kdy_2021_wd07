package com.jayasadha.inquiry_management;

public class Review {
	
	private int reid;
    private String message ;
    private double rating ;
    
    
	public Review(int reid, String message, double rating) {
	
		this.reid = reid;
		this.message = message;
		this.rating = rating;
	}


	public int getReid() {
		return reid;
	}


	public void setReid(int reid) {
		this.reid = reid;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}
    
    
  

}
