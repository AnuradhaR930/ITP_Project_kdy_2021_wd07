package com.jayasadha.return_refund_management;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ReportDBU {
	
	Report reportinstance;
	ArrayList<Report> list = new ArrayList<Report> ();
	
	public ArrayList<Report> getReport(Date from, Date to) throws SQLException{
		
		DBConnection dbc = new DBConnection();
		Connection con = dbc.getConnection();
		
		String query = "call total_sales_and_returns(?,?)";
		
		PreparedStatement ps = con.prepareStatement(query);
		
		ps.setDate(1, from);
		ps.setDate(2, to);
		
		ResultSet rs  = ps.executeQuery();
		
		while(rs.next()) {
			
			reportinstance = new Report(
			rs.getInt(1),
			rs.getInt(2),
			rs.getInt(3),
			rs.getString(4),
			rs.getDouble(5),
			rs.getString(6)
			);
			
		
		list.add(reportinstance);
			
		}
		
		return list;
	}

}
