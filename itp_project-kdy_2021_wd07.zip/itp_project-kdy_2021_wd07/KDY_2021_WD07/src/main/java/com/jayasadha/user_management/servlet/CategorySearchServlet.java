package com.jayasadha.user_management.servlet;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Image;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.StandardEntityCollection;
import org.jfree.data.jdbc.JDBCPieDataset;

import com.jayasadha.user_management.util.DBConnectionUtil;

/**
 * Servlet implementation class CategorySearchServlet
 */
@WebServlet("/CategorySearchServlet")
public class CategorySearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		try {
			JDBCPieDataset dataset = new JDBCPieDataset(DBConnectionUtil.getDBConnection());
			dataset.executeQuery("select Category, Quantity	from piechartc order by Quantity desc");
			
			JFreeChart chart = ChartFactory.createPieChart("", dataset, true, true, false);
			chart.setBorderPaint(Color.gray);
			chart.setBorderStroke(new BasicStroke(10.0f));
			chart.setBorderVisible(true);
			
			if(chart != null) {
				int width = 500;
				int height = 350;
				
				final ChartRenderingInfo info = new ChartRenderingInfo(new StandardEntityCollection());
				response.setContentType("image/png");
				OutputStream out = response.getOutputStream();
				ChartUtilities.writeChartAsPNG(out, chart, width, height, info);
				
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
