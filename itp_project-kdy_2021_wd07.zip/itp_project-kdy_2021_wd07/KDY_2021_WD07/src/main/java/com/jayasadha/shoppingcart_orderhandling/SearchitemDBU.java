package com.jayasadha.shoppingcart_orderhandling;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





public class SearchitemDBU {
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement st = null;
	private static ResultSet rs = null;
	
//	public static Lis searchI(String ItemName){
//
//		boolean isSuccess=false;
//
//					try {
//						con = DBConnection.getConnection();
//						st = con.createStatement();
//					
//						String sql = "SELECT EXISTS(SELECT * FROM jayasadha.shop WHERE ITName ='"+ItemName+"')";
//						ResultSet rs = st.executeQuery(sql);
//							
//					if(rs.next()){
//					
//					int value = rs.getInt(1);
//					
//					if(value>0) {
//					isSuccess = true;
//					}
//					else {
//					isSuccess = false;
//					}
//					}
//					}
//					catch(Exception e) {
//					e.printStackTrace();
//					}
//
//			return isSuccess;
//			}
	
	
	public static ArrayList<Shop> searchItem(String ItemName){
		
		
		ArrayList<Shop> s1 = new ArrayList<>();
		
		try {
			
			con = DBConnection.getConnection();
			st = con.createStatement();
			
			String sql = "select * from jayasadha.shop where ITName ='"+ItemName+"' ";
			rs = st.executeQuery(sql);
			
			
			
				 while(rs.next()) {
				 int itID = rs.getInt(1);
				 String itName = rs.getString(2);
				 Double itPrice = rs.getDouble(3);
				 String itImage = rs.getString(4);
			
				 
		
				 Shop shop = new Shop(itID ,itName , itPrice, itImage);
				 s1.add(shop);	 
			}
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
		
		return s1;
		
		}

}
