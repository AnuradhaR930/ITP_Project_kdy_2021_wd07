Please go under edit and edit this file as needed for your project

# Project Name - Online Textile Management System for “JayaSadha Textiles”
# Batch - KDY_2021_WD07
### Group Leader - IT20070212 -  Herath H.M.A.R (AnuradhaR930)
### Member 2 -     IT20068028 -  Ranasinghe R.B (it20068028)
### Member 3 -     IT20225674 -  Arambegama D.M.H.K.D (it20225674)
### Member 4 -     IT20268244 -  Kaleem F.A (It20268244)
### Member 5 -     IT20255756 -  Gunathilake N.M.A.H (IT20255756)
### Member 6 -     IT20049454 - Wijewardena T.P (thenu98)
### Member 7 -     IT20226664 - Herath T.H.M.S.R (SRHerath)
### Member 8 -     IT20218058 - Pathirathne P.S.R (Sandali-R) 

#### Brief Description of Project - This project is based on Online Textile Management System for “JayaSadha Textiles”
#### Technologies used - Java, jsp and Mysql for database

Note - The student's github account should be given in brackets e.g. (IT20212232), this ideally should be your student id 

