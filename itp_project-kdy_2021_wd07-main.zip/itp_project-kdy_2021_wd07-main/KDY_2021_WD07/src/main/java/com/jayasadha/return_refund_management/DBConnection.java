package com.jayasadha.return_refund_management;

import java.sql.*;

public class DBConnection {
	
	private String username = "root";
	private String password = "maatha";
	private String url = "jdbc:mysql://localhost:3306/jayasadha";
	
	//public DBConnection() {}
	
	//this will executes a given query and returns a result set
	
	public Connection getConnection() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url,username,password);
			return con;
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	

}
