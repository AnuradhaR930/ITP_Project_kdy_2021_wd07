package com.jayasadha.return_refund_management;

public class Report {

	private int itemId;
	private int totalSales;
	private int totalReturns;
	private String itemName;
	private double itemPrice;
	private String itemImage;
	
	public Report(int itemId, int totalSales, int totalReturns, String itemName, double itemPrice, String itemImage) {
		super();
		this.itemId = itemId;
		this.totalSales = totalSales;
		this.totalReturns = totalReturns;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemImage = itemImage;
	}

	public int getItemId() {
		return itemId;
	}

	public int getTotalSales() {
		return totalSales;
	}

	public int getTotalReturns() {
		return totalReturns;
	}

	public String getItemName() {
		return itemName;
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public String getItemImage() {
		return itemImage;
	}
	
	
	
}
