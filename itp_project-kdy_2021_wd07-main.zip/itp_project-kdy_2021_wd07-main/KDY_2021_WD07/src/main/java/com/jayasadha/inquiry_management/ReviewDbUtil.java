package com.jayasadha.inquiry_management;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ReviewDbUtil {
	
	 private static Connection con = null;
	
	 //insert rating
	public static boolean insertreview( String remessage, String rate, String itemid) {
		boolean isInsert = false;		
		
		 double rating_num = Double.parseDouble(rate);
		 int itemi = Integer.parseInt(itemid);
		
		try {
			
			 con = DbConnection.getDBConnection();
			 Statement st = con.createStatement();
			
			
			String db = "insert into review(reviewId,reMessage,rating,itemId)values(0,'"+remessage+"','"+rating_num+"','"+itemi+"')";
		
            int rs =  st.executeUpdate(db);
		    
		    if(rs > 0) {
		    	isInsert = true;
		    }
		    else {
		    	isInsert = false;
		    }
		
				
		
		}
		catch (Exception ex) {
			
			ex.printStackTrace();
		}
		
		return isInsert;
		
	}




   //review list

   public static List<ReviewView> getReviewList() {
    
           ArrayList <ReviewView> reviewlist = new ArrayList<>();
   
    
     try {
    	
    	  con = DbConnection.getDBConnection();
		  Statement s1 = con.createStatement();;
          String re_sql = "select * from reviewreportnew";
          ResultSet re1 = s1.executeQuery(re_sql);
        
         while(re1.next()) {
        	 
        	int re_supid = re1.getInt(1);
            String re_supname = re1.getString(2);
            int re_itemid =  re1.getInt(3);
            String re_itemname = re1.getString(4);
            String re_months = re1.getString(5);
            String  re_years= re1.getString(6);
            double re_rating = re1.getDouble(7);
        
            	                
            ReviewView all = new  ReviewView(re_supid,re_supname,re_itemid,re_itemname,re_months,re_years,re_rating);            
            reviewlist.add(all);
            
        }
    
       }catch(Exception e){
        
           e.printStackTrace();
       }
    
         return   reviewlist;
   } 

   
   
   
   //search list
   public static List<ReviewView> getReviewListSearch(String reviewLists) throws SQLException {
	    
       ArrayList <ReviewView> reviewlists = new ArrayList<>();


 try {
	
	  con = DbConnection.getDBConnection();
	  Statement s2 = con.createStatement();
      String re_sql = "select * from reviewreportnew where Supplier_name= '"+reviewLists+"'";
      ResultSet re3 = s2.executeQuery(re_sql);
    
     while(re3.next()) {
    	 
    	int re_supid = re3.getInt(1);
        String re_supname = re3.getString(2);
        int re_itemid =  re3.getInt(3);
        String re_itemname = re3.getString(4);
        String re_months = re3.getString(5);
        String  re_years= re3.getString(6);
        double re_rating = re3.getDouble(7);
    
        	                
        ReviewView all1 = new  ReviewView(re_supid,re_supname,re_itemid,re_itemname,re_months,re_years,re_rating);            
        reviewlists.add(all1);
        
        for (ReviewView a: reviewlists) {
			System.out.println(a.getV_supid());
		}
        
    }
    

   }catch(Exception e){
    
       e.printStackTrace();
   }

     return   reviewlists;
} 


}
