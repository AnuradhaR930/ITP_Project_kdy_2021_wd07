package com.jayasadha.return_refund_management;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ret_report")
public class ReportController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//gettng the date
		
		String date_f = request.getParameter("date_f");
		String date_t = request.getParameter("date_t");
		
		Date d_f = Date.valueOf(date_f);
		Date d_t = Date.valueOf(date_t);
		
		//getting report details
		
		ReportDBU reportdbu = new ReportDBU();
		ArrayList<Report> list = new ArrayList<Report>();
		
		try {
			
			list = reportdbu.getReport(d_f, d_t);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		//dispatching request into view report servlet
		
		//response.getWriter().print(list.get(0).getItemName());
		
		request.setAttribute("ret_report_data", list);
		
		request.getRequestDispatcher("ret_admin_view_report.jsp").forward(request, response);
		
	}

}
