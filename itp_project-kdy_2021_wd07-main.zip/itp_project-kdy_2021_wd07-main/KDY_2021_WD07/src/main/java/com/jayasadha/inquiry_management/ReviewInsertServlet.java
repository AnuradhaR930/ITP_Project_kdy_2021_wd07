package com.jayasadha.inquiry_management;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ReviewInsertServlet
 */
@WebServlet("/ReviewInsertServlet")
public class ReviewInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		
		String remessage = request.getParameter("remessage");
		String rate = request.getParameter("rate");
		String itemid = request.getParameter("itemID");
	
		
		boolean isTrue;
		isTrue = ReviewDbUtil.insertreview( remessage, rate, itemid);
		
		if(isTrue == true) {
			RequestDispatcher rd = request.getRequestDispatcher("contactSubmit.jsp");
			rd.forward(request, response);
		}
		else { 
			
			RequestDispatcher rd2 = request.getRequestDispatcher("contactNotSubmit.jsp");
			rd2.forward(request, response);
		}
		
	}

}
