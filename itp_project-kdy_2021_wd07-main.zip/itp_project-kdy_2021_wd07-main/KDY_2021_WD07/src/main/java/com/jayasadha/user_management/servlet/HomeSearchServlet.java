package com.jayasadha.user_management.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jayasadha.user_management.model.Customer;
import com.jayasadha.user_management.model.Shops;
import com.jayasadha.user_management.service.CustomerDBQuery;

/**
 * Servlet implementation class HomeSearchServlet
 */
@WebServlet("/HomeSearchServlet")
public class HomeSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*
		 * response.getWriter().append("Served at: ").append(request.getContextPath());
		 */

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String category = null, brand = null;

		String search = request.getParameter("hSearch");

		CustomerDBQuery c1 = new CustomerDBQuery();

		boolean isTrue, inserted;
		isTrue = c1.validateSearch(search);

		if (isTrue == true) {

			List<Shops> searchData = c1.getSearchResults(search);
			request.setAttribute("searchData", searchData);

			for (Shops a : searchData) { 
				category = a.getItemCategory(); 
				brand = a.getItemBrand();
			}
			
			inserted = c1.insertSearchData(category, brand);
			if(inserted == true) {
				System.out.println("success");
			}else {
				System.out.println("fail");
			}			

			request.getRequestDispatcher("VisitorHome.jsp").include(request, response);

		} else {
			out.println("<script type='text/javascript'>");
			out.println("alert('Sorry!!! Not found any search result');");
			out.println("location='VisitorHome.jsp'");
			out.println("</script>");
		}

	}

}
