package com.jayasadha.inquiry_management;

public class ReviewView {
	
	private int v_supid;
    private String v_supname ;
    private int v_itemid;
    private String v_itemname ;
    private String v_months ;
    private String year ;
    private double v_rating;
    
    
	public ReviewView(int v_supid, String v_supname, int v_itemid, String v_itemname, String v_months, String year,
			double v_rating) {
		
		this.v_supid = v_supid;
		this.v_supname = v_supname;
		this.v_itemid = v_itemid;
		this.v_itemname = v_itemname;
		this.v_months = v_months;
		this.year = year;
		this.v_rating = v_rating;
	}


	public int getV_supid() {
		return v_supid;
	}


	public void setV_supid(int v_supid) {
		this.v_supid = v_supid;
	}


	public String getV_supname() {
		return v_supname;
	}


	public void setV_supname(String v_supname) {
		this.v_supname = v_supname;
	}


	public int getV_itemid() {
		return v_itemid;
	}


	public void setV_itemid(int v_itemid) {
		this.v_itemid = v_itemid;
	}


	public String getV_itemname() {
		return v_itemname;
	}


	public void setV_itemname(String v_itemname) {
		this.v_itemname = v_itemname;
	}


	public String getV_months() {
		return v_months;
	}


	public void setV_months(String v_months) {
		this.v_months = v_months;
	}


	public String getYear() {
		return year;
	}


	public void setYear(String year) {
		this.year = year;
	}


	public double getV_rating() {
		return v_rating;
	}


	public void setV_rating(double v_rating) {
		this.v_rating = v_rating;
	}
	
	
	
   
}
